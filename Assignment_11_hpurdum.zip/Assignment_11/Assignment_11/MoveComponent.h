#pragma once

#include "Component.h"

class MoveComponent : public Component
{
public:
    MoveComponent(class Actor* pActorOwner);
    ~MoveComponent();

    void Update(float deltaTime) override;

    void SetForwardSpeed(float spd) { _fForwardSpeed = spd; }
    void SetAngularSpeed(float spd) { _fAngularSpeed = spd; }

private:
    // Controls rotation (radians/second)
    float _fAngularSpeed;
    // Controls the forward movement (units/second)
    float _fForwardSpeed;
};

