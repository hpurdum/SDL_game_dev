//
//  AsteroidActor.h
//  Assignment_11
//
//  Created by Henry Purdum on 4/15/22.
//

#ifndef AsteroidActor_h
#define AsteroidActor_h

#include "SpriteComponent.h"
#include "MoveComponent.h"
#include "Actor.h"

class AsteroidActor : public Actor {
public:
    AsteroidActor(Game* game);
    ~AsteroidActor();
    virtual void Update();
    void UpdateActor(float deltaTime);
private:
    SpriteComponent* sc;
    MoveComponent* mc;
};

#endif /* AsteroidActor_h */
