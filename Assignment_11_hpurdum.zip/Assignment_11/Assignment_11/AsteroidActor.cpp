//
//  AsteroidActor.cpp
//  Assignment_11
//
//  Created by Henry Purdum on 4/15/22.
//

#include <stdio.h>
#include "Random.h"
#include "Game.h"
#include "Math.h"
#include "AsteroidActor.h"

AsteroidActor::AsteroidActor(Game* game) : Actor::Actor(game) {
    SDL_Texture* tex = game->GetTexture("assets/Asteroid.png");
    
    sc = new SpriteComponent(this);
    sc->SetTexture(tex);
    Actor::AddComponent(sc);
    
    mc = new MoveComponent(this);
    mc->SetForwardSpeed(100.0f);
    mc->SetAngularSpeed(0.0f);
    Actor::SetRotation(Random::GetFloat()*90);
    Actor::AddComponent(mc);
}

AsteroidActor::~AsteroidActor() {
    Actor::RemoveComponent(sc);
    Actor::RemoveComponent(mc);
}

void AsteroidActor::UpdateActor(float deltaTime) {
    Actor::UpdateActor(deltaTime);
}

void AsteroidActor::Update() {
    
}
