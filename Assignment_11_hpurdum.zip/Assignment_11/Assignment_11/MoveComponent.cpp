#include "MoveComponent.h"
#include "Actor.h"
#include "Math.h"

MoveComponent::MoveComponent(Actor* pActorOwner)
    : Component(pActorOwner) {
    _fAngularSpeed = 0.0f;
    _fForwardSpeed = 0.0f;
}


MoveComponent::~MoveComponent()
{
}

// Update override, called every frame by actor owner.
void MoveComponent::Update(float deltaTime) {
    if( !Math::NearZero(_fAngularSpeed) )
        {
            //Tell the owning actor to rotate
            float rot = _pOwner->GetRotation();
            rot += _fAngularSpeed * deltaTime;
            _pOwner->SetRotation(rot);
        }

        //Tell the owning actor to move
        if ( !Math::NearZero(_fForwardSpeed) )
        {
            Vector2 pos = _pOwner->GetPosition();
            pos += _pOwner->GetForward() * _fForwardSpeed * deltaTime;

            //Screen wrapping
            if(pos.x > 1024) //Checking x on the right
            {
                pos.x = 0;
            }
            if(pos.x < 0) //Checking x on the left
            {
                pos.x = 1024;
            }
            if(pos.y > 768) //Checking y on the top
            {
                pos.y = 0;
            }
            if(pos.y < 0) //Checking x on the right
            {
                pos.y = 768;
            }

            _pOwner->SetPosition(pos);
        }

}
