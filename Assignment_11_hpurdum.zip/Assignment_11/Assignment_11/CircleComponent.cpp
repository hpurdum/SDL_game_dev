#include "CircleComponent.h"
#include "Actor.h"


CircleComponent::CircleComponent(Actor* pOwner)
: Component(pOwner) {
    _fRadius = 0.0f;
}

CircleComponent::~CircleComponent() {
}

const Vector2& CircleComponent::GetCenter() const {
    return _pOwner->GetPosition();
}

float CircleComponent::GetRadius() const {
    return _pOwner->GetScale()* _fRadius;
}

// Method to determine if this CircleComponent
// is colliding with other.
bool CircleComponent::Intersect(const CircleComponent& other) {
    // Calculate distance squared between this and other.
    Vector2 diff = this->GetCenter() - other.GetCenter();
    float distSquared = diff.LengthSq();

    // Calculate sum of radii squared.
    float radiiSquared = this->GetRadius() + other.GetRadius();
    radiiSquared *= radiiSquared;

    return distSquared <= radiiSquared;
}
