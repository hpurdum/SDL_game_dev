//
//  ShipActor.cpp
//  Assignment_11
//
//  Created by Henry Purdum on 4/15/22.
//

#include <stdio.h>
#include "ShipActor.h"

ShipActor::ShipActor(Game* game) : Actor::Actor(game) {
    SDL_Texture* tex = game->GetTexture("assets/Ship.png");
    
    sc = new SpriteComponent(this);
    sc->SetTexture(tex);
    Actor::AddComponent(sc);
    
    ic = new InputComponent(this);
    ic->SetForwardKey(SDL_SCANCODE_W);
    ic->SetBackwardKey(SDL_SCANCODE_S);
    ic->SetClockwiseKey(SDL_SCANCODE_D);
    ic->SetCounterClockwiseKey(SDL_SCANCODE_A);
    Actor::AddComponent(ic);
}

ShipActor::~ShipActor() {
    Actor::RemoveComponent(sc);
    Actor::RemoveComponent(ic);
}

void ShipActor::UpdateActor(float deltaTime) {
    Actor::UpdateActor(deltaTime);
}

void ShipActor::Update() {
    
}
