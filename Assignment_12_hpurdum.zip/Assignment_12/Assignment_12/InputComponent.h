#pragma once
#include "MoveComponent.h"
#include "SDL2/SDL.h"

class InputComponent : public MoveComponent
{
public:
    InputComponent(class Actor* pOwner);

    virtual void ProcessInput(const Uint8* pKeyboardState);
    
    void SetForwardKey(int key) { _nForwardKey = key;}
    void SetBackwardKey(int key) { _nBackwardKey = key;}
    void SetClockwiseKey(int key) { _nClockwiseKey = key;}
    void SetCounterClockwiseKey(int key) { _nCounterClockwiseKey = key;}

private:
    int _nForwardKey;
    int _nBackwardKey;
    int _nClockwiseKey;
    int _nCounterClockwiseKey;
    
    float _nMaxForwardSpeed = 100.0f;
    float _nMaxAngularSpeed = 2.0f;
};

