// ----------------------------------------------------------------
// From Game Programming in C++ by Sanjay Madhav
// Copyright (C) 2017 Sanjay Madhav. All rights reserved.
// 
// Released under the BSD License
// See LICENSE in root directory for full details.
// ----------------------------------------------------------------

#pragma once
#include <cstdint>

class Component
{
public:
	// Constructor
	Component(class Actor* owner);
	// Destructor
	virtual ~Component();
	// Update this component by delta time
	virtual void Update(float deltaTime);

	// ProcessInput method that is handed the state of the
	// keyboard.
	// Overridable, but empty here if a component does not
	// need the keyboard state.
	virtual void ProcessInput(const uint8_t* pKeyboardState) {}
	
protected:
	// Owning actor
	class Actor* _pOwner;
};
