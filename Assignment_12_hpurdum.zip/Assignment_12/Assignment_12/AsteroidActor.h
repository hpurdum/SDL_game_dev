//
//  AsteroidActor.h
//  Assignment_11
//
//  Created by Henry Purdum on 4/15/22.
//

#ifndef AsteroidActor_h
#define AsteroidActor_h

#include "SpriteComponent.h"
#include "MoveComponent.h"
#include "CircleComponent.h"
#include "Actor.h"

class AsteroidActor : public Actor {
public:
    AsteroidActor(Game* game);
    ~AsteroidActor();
    virtual void Update();
    void UpdateActor(float deltaTime);
    CircleComponent& GetCircleComponent() {return *cc;}
private:
    SpriteComponent* sc;
    MoveComponent* mc;
    CircleComponent* cc;
};

#endif /* AsteroidActor_h */
