//
//  LaserActor.cpp
//  Assignment_12
//
//  Created by Henry Purdum on 4/29/22.
//

#include <stdio.h>
#include "LaserActor.h"
#include "Random.h"
#include "Game.h"
#include "Math.h"
#include "MoveComponent.h"
#include "SpriteComponent.h"

LaserActor::LaserActor(Game* game) : Actor::Actor(game) {
    deathTimer = 50;
    SDL_Texture* tex = game->GetTexture("assets/Laser.png");
    
    sc = new SpriteComponent(this);
    sc->SetTexture(tex);
    Actor::AddComponent(sc);
    
    mc = new MoveComponent(this);
    mc->SetForwardSpeed(100.0f);
    mc->SetAngularSpeed(0.0f);
    Actor::AddComponent(mc);
    
    cc = new CircleComponent(this);
    cc->SetRadius(11.0f);
    Actor::AddComponent(cc);
    
    _vecAsteroids = game->GetAsteroids();
}
LaserActor::~LaserActor() {
    delete sc;
    delete mc;
    delete cc;
}

void LaserActor::UpdateActor(float deltaTime) {
    Actor::UpdateActor(deltaTime);
    deathTimer--;
    if(deathTimer <= 0) {
        SetState(EDead);
    }
    else {
        // if laser is still alive check if collides with circle component of asteroids in game
        for(AsteroidActor* asteroid : _vecAsteroids) {
            if(cc->Intersect(asteroid->GetCircleComponent())) {
                asteroid->SetState(EDead);
                SetState(EDead);
            }
        }
    }
}

void LaserActor::Update() {
    
}
