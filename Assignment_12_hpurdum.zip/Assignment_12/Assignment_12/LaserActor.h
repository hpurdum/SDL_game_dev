//
//  LaserActor.h
//  Assignment_12
//
//  Created by Henry Purdum on 4/29/22.
//

#ifndef LaserActor_h
#define LaserActor_h

#include "SpriteComponent.h"
#include "MoveComponent.h"
#include "CircleComponent.h"
#include "Actor.h"
#include "Game.h"

class LaserActor : public Actor {
public:
    LaserActor(Game* game);
    ~LaserActor();
    virtual void Update();
    void UpdateActor(float deltaTime);
private:
    SpriteComponent* sc;
    MoveComponent* mc;
    CircleComponent* cc;
    int deathTimer;
    std::vector<AsteroidActor*> _vecAsteroids;
};

#endif /* LaserActor_h */
