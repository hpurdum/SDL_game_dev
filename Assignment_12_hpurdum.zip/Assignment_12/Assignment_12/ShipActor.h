//
//  ShipActor.h
//  Assignment_11
//
//  Created by Henry Purdum on 4/15/22.
//

#ifndef ShipActor_h
#define ShipActor_h

#include "SpriteComponent.h"
#include "InputComponent.h"
#include "LaserActor.h"
#include "Actor.h"
#include "Game.h"

class ShipActor : public Actor {
public:
    ShipActor(Game* game);
    ~ShipActor();
    virtual void Update();
    void UpdateActor(float deltaTime) override;
    void ActorInput(const uint8_t *keyState) override;
private:
    SpriteComponent* sc;
    InputComponent* ic;
    LaserActor* laser;
    int laserCoolDown;
};

#endif /* ShipActor_h */
