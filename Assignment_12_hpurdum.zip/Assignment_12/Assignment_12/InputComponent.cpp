#include "InputComponent.h"
#include "Actor.h"
#include "LaserActor.h"


InputComponent::InputComponent(Actor* pOwner)
: MoveComponent(pOwner) {
    _nForwardKey = 0;
    _nBackwardKey = 0;
    _nClockwiseKey = 0;
    _nCounterClockwiseKey = 0;
}

// Public method that is handed the keyboard state
// every iteration to process.
void InputComponent::ProcessInput(const Uint8* pKeyboardState) {
    // Calculate the forward speed of this MoveComponent.
    // Remember, InputComponent "is a" MoveComponent.
    float forwardSpeed = 0.0f;
    if (pKeyboardState[_nForwardKey]) {
        forwardSpeed += _nMaxForwardSpeed;
        // TODO: make this a _nMaxForwardSpeed attribute.
    }
    if (pKeyboardState[_nBackwardKey]) {
        forwardSpeed -= _nMaxForwardSpeed;
        // TODO: make this a _nMaxForwardSpeed attribute.
    }
    SetForwardSpeed(forwardSpeed);

    // Calculate the angular speed for this MoveComponent.
    float angularSpeed = 0.0f;
    if (pKeyboardState[_nClockwiseKey]) {
        angularSpeed += _nMaxAngularSpeed;
        // TODO: make this a _nMaxAngularSpeed attribute.
    }
    if (pKeyboardState[_nCounterClockwiseKey]) {
        angularSpeed -= _nMaxAngularSpeed;
        // TODO: make this a _nMaxAngularSpeed attribute.
    }

    // TODO: Tell parent MoveComponent to SetAngularSpeed.
    SetAngularSpeed(angularSpeed);
}
